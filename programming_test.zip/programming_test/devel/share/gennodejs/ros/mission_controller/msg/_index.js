
"use strict";

let PosGoal = require('./PosGoal.js');
let PosActionFeedback = require('./PosActionFeedback.js');
let PosActionGoal = require('./PosActionGoal.js');
let PosAction = require('./PosAction.js');
let PosResult = require('./PosResult.js');
let PosFeedback = require('./PosFeedback.js');
let PosActionResult = require('./PosActionResult.js');

module.exports = {
  PosGoal: PosGoal,
  PosActionFeedback: PosActionFeedback,
  PosActionGoal: PosActionGoal,
  PosAction: PosAction,
  PosResult: PosResult,
  PosFeedback: PosFeedback,
  PosActionResult: PosActionResult,
};
