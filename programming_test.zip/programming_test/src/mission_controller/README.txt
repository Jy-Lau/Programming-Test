rostopic pub /pos/goal mission_controller/PosActionGoal "header:
  seq: 0
  stamp:
    secs: 0
    nsecs: 0
  frame_id: ''
goal_id:
  stamp:
    secs: 0
    nsecs: 0
  id: ''
goal:
  data:
    layout:
      dim: []
      data_offset: 0
    data: [7.0,13.0,6.0,55.0,100.0,66.0]"