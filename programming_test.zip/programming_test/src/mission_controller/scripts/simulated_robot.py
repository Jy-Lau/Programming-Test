
import numpy as np
import threading
import random
import rospy

class SimulatedRobot:

    def __init__(self, initial_position, update_position_callback=None):
        rospy.loginfo("Creating SimulatedRobot!")
        self.position = initial_position
        self.update_position_callback = update_position_callback
        self.nav_lock = threading.Lock()

    def get_position(self):
        return self.position

    def set_navigation_command(self, waypoint):
        with self.nav_lock:
            rospy.loginfo(f"Commanding robot to move to {waypoint} from SimulatedRobot")
            self.waypoint = waypoint
            rospy.loginfo(f"Robot is now at {waypoint}")
            self.position = waypoint
            self.update_position_callback(waypoint)
        


class SimulatedRobotWithCommunicationDelay:

    def __init__(self, initial_position):
        self._robot = SimulatedRobot(initial_position, self.set_position)
        self.position = initial_position

    def set_position(self, position):
        self.position = position

    def get_position(self):
        return self.position

    def set_navigation_command(self, waypoint):
        self._robot.set_navigation_command(waypoint)
