
import numpy as np
from threading import Thread
import rospy
import time

class MissionController:

    def __init__(self, robot):
        rospy.loginfo("Creating MissionController!")
        self.robot = robot
        self.trajectory = np.zeros((1,2), dtype=np.float64)
        self.current_waypoint_idx=0
        self.max_waypoint=0
        self.thread_poll_position = Thread(target=self._poll_position, daemon=True)
        self.thread_poll_position.start()


    def set_trajectory(self, trajectory):
        self.trajectory = trajectory
        self.max_waypoint=len(trajectory)
        self.current_waypoint_idx=0
        if self.max_waypoint<=0:
            rospy.loginfo((f'Stop the robot!'))

    def _poll_position(self):
        while True:
            time.sleep(2.0)
            position = self.robot.get_position()
            rospy.loginfo((f'Robot current position: {position}'))
            if self.max_waypoint>self.current_waypoint_idx:
                self._send_navigation_command(self.current_waypoint_idx)
                if np.all(position == self.trajectory[self.current_waypoint_idx]):
                    self.current_waypoint_idx += 1
                

    def _send_navigation_command(self,waypoint):
        rospy.loginfo(f"Sending waypoint {waypoint}")
        self.robot.set_navigation_command(self.trajectory[waypoint])
