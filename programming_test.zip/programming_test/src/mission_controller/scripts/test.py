#!/usr/bin/env python3
import numpy as np
from missioncontroller import MissionController
from simulated_robot import SimulatedRobot, SimulatedRobotWithCommunicationDelay
from std_msgs.msg import Float64MultiArray
import actionlib
from mission_controller.msg import PosAction,PosFeedback,PosResult
import rospy

class Test():
    def __init__(self):
        rospy.init_node('test_node', anonymous=True)
        self.simulated_robot = SimulatedRobotWithCommunicationDelay(np.array([0.0, 0.0]))
        self.controller = MissionController(self.simulated_robot)
        self.feedback = PosFeedback()
        self.result = PosResult()
        self.server = actionlib.SimpleActionServer('pos',PosAction,execute_cb=self.execute_cb,auto_start=False)
        self.server.start()

    def execute_cb(self,goal):
        rospy.loginfo(f'Received goal\n{goal}')
        lenofdata = len(goal.data.data)
        input_array = np.empty((1, 2), dtype=np.float64)
        if lenofdata % 2 !=0 :
            rospy.logerr('Wrong matching length of input data')
            self.server.set_succeeded(False)
            return
        elif lenofdata ==0:
            input_array=np.array([],dtype=np.float64)
        else:
            input_array = np.array(goal.data.data, dtype=np.float64)
            input_array = np.reshape(input_array,(lenofdata//2,-1))
        success = True
        rospy.loginfo(f'Input array: {input_array}')
        self.controller.set_trajectory(input_array)
        rospy.sleep(1)
        self.feedback.feedback = Float64MultiArray()
        
        while lenofdata >0 and np.all(self.simulated_robot.get_position == input_array[-1]) is not True:
            self.feedback.feedback.data = self.simulated_robot.get_position().flatten().tolist()
            self.server.publish_feedback(self.feedback)
            # check that preempt has not been requested by the client
            if self.server.is_preempt_requested():
                rospy.loginfo('Preempted pos')
                self.server.set_preempted()
                success = False
                break
        if success:
            self.result.status = success
            self.server.set_succeeded(self.result)

if __name__ == "__main__":
    test = Test()
    rospy.spin()
    
